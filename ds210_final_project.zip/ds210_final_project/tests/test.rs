use librs;

use std::collections::{HashMap, HashSet};
use librs::hashtag_loader::read_hashtags_from_file;
use librs::hashtag_processor::HashtagCounter;
use librs::weighted_graph_creator::construct_weighted_graph;
use librs::shortest_path::dijkstra_distances;
use librs::rank_distance::sorting_from_smallest;

type Graph = HashMap<String, HashMap<String, i32>>;

#[test]
fn test_read_hashtags_from_file() {
    let hashtags = read_hashtags_from_file("test2.csv", 10).unwrap();
    let expected_hashtags:HashSet<String> = vec![
        String::from("bitcoin"),
        String::from("Bitcoin"),
        String::from("Ethereum"),
        String::from("Happy"),
        String::from("ETH"),
    ].into_iter().collect();

    assert_eq!(hashtags, expected_hashtags);
}

#[test]
fn test_count_hashtags() {
    let hashtags: Vec<String> = vec![
        String::from("bitcoin"),
        String::from("Bitcoin"),
        String::from("Ethereum"),
        String::from("Happy"),
        String::from("ETH"),
    ]
    .into_iter()
    .collect();

    let mut hashtag_counter = HashtagCounter::new(hashtags);
    hashtag_counter.count_hashtags("test2.csv", 10).unwrap();
    let result = hashtag_counter.get_collection();

    let mut expected_result = HashMap::new();
    expected_result.insert(
        String::from("bitcoin"),
        vec![vec![String::from("Happy")]],
    );
    expected_result.insert(
        String::from("Bitcoin"),
        vec![
            vec![String::from("Happy")],
            vec![String::from("Ethereum"), String::from("ETH")],
        ],
    );
    expected_result.insert(
        String::from("Ethereum"),
        vec![vec![String::from("ETH"), String::from("Bitcoin")]],
    );
    expected_result.insert(
        String::from("Happy"),
        vec![vec![String::from("bitcoin")],
        vec![String::from("Bitcoin")],
        ],
    );

    expected_result.insert(
        String::from("ETH"),
        vec![vec![String::from("Ethereum"), String::from("Bitcoin")]],
    );

    assert_eq!(result, expected_result);
}

#[test]
fn test_count_edges() {
    use std::collections::HashMap;

    let mut collection:HashMap<String, Vec<Vec<String>>> = HashMap::new();
    collection.insert(
        String::from("bitcoin"),
        vec![vec![String::from("Happy")]],
    );
    collection.insert(
        String::from("Bitcoin"),
        vec![
            vec![String::from("Happy")],
            vec![String::from("Ethereum"), String::from("ETH")],
        ],
    );
    collection.insert(
        String::from("Ethereum"),
        vec![vec![String::from("ETH"), String::from("Bitcoin")]],
    );
    collection.insert(
        String::from("Happy"),
        vec![vec![String::from("bitcoin"), String::from("Bitcoin")]],
    );

    let result = construct_weighted_graph(collection);

    let mut hash_for_bitcoin = HashMap::new();
    hash_for_bitcoin.insert("Happy".to_string(), 1);

    let mut hash_for_bitcoin2 = HashMap::new();
    hash_for_bitcoin2.insert("Happy".to_string(), 1);
    hash_for_bitcoin2.insert("Ethereum".to_string(), 1);
    hash_for_bitcoin2.insert("ETH".to_string(), 1);

    let mut hash_for_etherum = HashMap::new();
    hash_for_etherum.insert("Bitcoin".to_string(), 1);
    hash_for_etherum.insert("ETH".to_string(), 1);

    let mut expected_happy = HashMap::new();
    expected_happy.insert("Bitcoin".to_string(), 1);
    expected_happy.insert("bitcoin".to_string(), 1);

    let mut expected_result:HashMap<String, HashMap<String, i32>> = HashMap::new();
    expected_result.insert("bitcoin".to_string(), hash_for_bitcoin);
    expected_result.insert("Bitcoin".to_string(), hash_for_bitcoin2);
    expected_result.insert("Ethereum".to_string(), hash_for_etherum);
    expected_result.insert("Happy".to_string(), expected_happy);

    // ... populate the expected_result with expected data ...

    assert_eq!(result, expected_result);
}

fn sample_graph() -> Graph {
    let mut graph = HashMap::new();

    graph.insert("A".to_string(), {
        let mut neighbors = HashMap::new();
        neighbors.insert("B".to_string(), 1);
        neighbors.insert("C".to_string(), 4);
        neighbors
    });

    graph.insert("B".to_string(), {
        let mut neighbors = HashMap::new();
        neighbors.insert("D".to_string(), 2);
        neighbors.insert("E".to_string(), 3);
        neighbors
    });

    graph.insert("C".to_string(), {
        let mut neighbors = HashMap::new();
        neighbors.insert("F".to_string(), 5);
        neighbors.insert("G".to_string(), 4);
        neighbors
    });

    graph
}

#[test]
fn test_dijkstra_distances() {
    let graph = sample_graph();
    let start = "A";
    let result = dijkstra_distances(&graph, start);

    let mut expected_result = HashMap::new();
    expected_result.insert("A".to_string(), 0.0);
    expected_result.insert("B".to_string(), (1.0)*100000.0);
    expected_result.insert("C".to_string(), (1.0/4.0)*100000.0);
    expected_result.insert("D".to_string(), (1.5)*100000.0);
    expected_result.insert("E".to_string(), (1.0+(1.0/3.0))*100000.0);
    expected_result.insert("F".to_string(), (0.45)*100000.0);
    expected_result.insert("G".to_string(), (0.5)*100000.0);


    assert_eq!(result, expected_result);
}

#[test]
fn test_sorting_from_smallest() {

    let mut test = HashMap::new();
    test.insert("tag1".to_string(), 0.5);
    test.insert("tag2".to_string(), 0.3);
    test.insert("tag3".to_string(), 0.7);
    test.insert("tag4".to_string(), 0.2);
    test.insert("tag5".to_string(), 0.9);

    let result = sorting_from_smallest(test, 3);

    let expected_result = vec![
        ("tag4".to_string(), 0.2),
        ("tag2".to_string(), 0.3),
        ("tag1".to_string(), 0.5),
    ];

    assert_eq!(result, expected_result);
}