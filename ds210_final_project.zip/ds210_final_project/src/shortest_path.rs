use std::cmp::Ordering;
use std::collections::{BinaryHeap, HashMap};

type Graph = HashMap<String, HashMap<String, i32>>;

//Define a custom distance wrapper to handle floating-point comparisons
#[derive(Clone, PartialEq)]
struct Distance(f32);

//Implement the Eq trait for Distance
impl Eq for Distance {}

//Implement the PartialOrd trait for Distance
impl PartialOrd for Distance {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        self.0.partial_cmp(&other.0)
    }
}

//Implement the Ord trait for Distance
impl Ord for Distance {
    fn cmp(&self, other: &Self) -> Ordering {
        self.partial_cmp(other).unwrap_or(Ordering::Equal)
    }
}

//Define a state for Dijkstra's algorithm, consisting of a distance and a node
#[derive(Clone, PartialEq)]
struct State {
    distance: Distance,
    node: String,
}

//Implement the Eq trait for State
impl Eq for State {}

//Implement the PartialOrd trait for State
impl PartialOrd for State {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

//Implement the Ord trait for State
impl Ord for State {
    fn cmp(&self, other: &Self) -> Ordering {
        self.distance.cmp(&other.distance)
    }
}

//Implement Dijkstra's algorithm to compute the shortest path distances from the start node to all other nodes in the graph
pub fn dijkstra_distances(graph: &Graph, start: &str) -> HashMap<String, f32> {
    let mut distances = HashMap::new(); // Store shortest path distances
    let mut heap = BinaryHeap::new(); // Create a binary heap

    //Initialize the starting node distance to 0
    distances.insert(start.to_string(), 0.0);
    heap.push(State {
        distance: Distance(0.0),
        node: start.to_string(),
    });

    //Continue processing nodes in the heap until it is empty
    while let Some(State { distance, node }) = heap.pop() {
        //Get the neighbors of the current node, if any
        if let Some(neighbors) = graph.get(&node) {
            //Iterate through the neighbors and their edge weights
            for (neighbor, weight) in neighbors {
                //Calculate the new distance through the current node
                let new_distance = distance.0 + ((1.0 / *weight as f32)*100000.0);
                //indicate that the distance is "inverted"
                let inverted_new_distance = new_distance;
                
                //Update the distance if this is the first time visiting the neighbor or if the new distance is shorter
                if !distances.contains_key(neighbor) || inverted_new_distance < distances[neighbor] {
                    distances.insert(neighbor.to_string(), new_distance);
                    heap.push(State {
                        distance: Distance(inverted_new_distance),
                        node: neighbor.to_string(),
                    });
                }
            }
        }
    }

    //Return the shortest path distances from the start node to all other nodes
    distances
}

