use std::collections::HashMap;

//Function to sort the given HashMap by value (distance) and return the top 'threshold' entries as a vector of tuples
pub fn sorting_from_smallest(new_collection2: HashMap<String, f32>, threshold: usize) -> Vec<(String, f32)> {

    //Convert the HashMap into a vector of tuples (key, value)
    let mut vector_of_tuples: Vec<(String, f32)> = new_collection2.into_iter().collect();

    //Sort the vector of tuples by the second element (value) in ascending order
    vector_of_tuples.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap());

    //Truncate the vector to only include the top 'threshold' number of tuples
    vector_of_tuples.truncate(threshold);

    println!("Result: ");
    //Iterate through the truncated vector of tuples and print the results
    for (x, y) in &vector_of_tuples {
        println!(
            "hashtag {:?}: has a distance {:?} away from the hashtag Bitcoin",
            x, y
        );
    }

    //Return the truncated vector of tuples
    vector_of_tuples
}
