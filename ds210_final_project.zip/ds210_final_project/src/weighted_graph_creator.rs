use std::collections::HashMap;

//Define a type alias for a graph to improve code readability
type Graph = HashMap<String, HashMap<String, i32>>;

//Count the edges (connections) between a hashtag and other tags in a Vec of tags
fn count_edges_for_hashtag(hashtag: &str, all_tags_vec: &[Vec<String>]) -> HashMap<String, i32> {
    let mut edge_counts = HashMap::new();
    
    //Iterate through each set of tags in the given list
    for tags_group in all_tags_vec {
        //Iterate through each tag in the current set
        for tag in tags_group {
            //If the current tag is not the hashtag we're counting edges for
            if tag != hashtag {
                //Increment the count of edges between the hashtag and the current tag
                *edge_counts.entry(tag.to_string()).or_insert(0) += 1;
            }
        }
    }
    edge_counts
}

//Count the edges between hashtags and other tags in the given collection
pub fn construct_weighted_graph(collection: HashMap<String, Vec<Vec<String>>>) -> Graph {
    let mut graph = HashMap::new();
    
    //Iterate through each pair in the collection
    for (hashtag, tags_vec) in &collection {
        //Count the edges for the current hashtag and store them in a HashMap
        let edge_counts = count_edges_for_hashtag(hashtag, tags_vec);
        
        //Insert the edge counts for the current hashtag into the graph
        graph.insert(hashtag.to_string(), edge_counts);
    }
    
    graph
}

