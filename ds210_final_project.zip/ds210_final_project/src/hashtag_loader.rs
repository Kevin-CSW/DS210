use csv::ReaderBuilder;
use std::error::Error;
use std::fs::File;
use std::collections::HashSet;

//Function to read hashtags from a CSV file and store them in a HashSet
pub fn read_hashtags_from_file(filename: &str, column_numb: usize) -> Result<HashSet<String>, Box<dyn Error>> {
    //Open the input file
    let file = File::open(filename)?;

    //Create a CSV reader with headers enabled and flexible parsing
    let mut rdr = ReaderBuilder::new()
        .has_headers(true)
        .flexible(true)
        .from_reader(file);

    //Create a HashSet to store the unique hashtags
    let mut hashtags = HashSet::new();
    let mut count = 0;

    //Iterate through the records in the CSV file
    for result in rdr.records() {
        // Get the record and handle errors
        let record = result?;

        //Check for missing or abnormal data (e.g., "NA" or empty fields)
        //let has_na = record.iter().any(|field| field == "NA" || field.trim().is_empty());
        //This line is commented out because, for this specific dataset, the hashtag column is quite clean
        //compared to other columns, and dropping rows with NAs would result in a significant loss of data.
        //However, this code snippet is retained as it may be useful for handling other datasets.

        
        //Extract the tags string from the specified column and trim any unnecessary characters
        let mut tags = record.get(column_numb).unwrap_or_default().to_string();
        tags = tags.trim_matches(|c| c == '[' || c == ']').replace('\'', "");

        //Split the tags string into a vector of individual tags
        let tags_vec: Vec<&str> = tags.split(", ").collect();
        count += 1;

        //Iterate through the tags vector and insert non-empty tags into the hashtags HashSet
        for tag in tags_vec {
            if !tag.is_empty() {
                hashtags.insert(tag.to_string());
            }
        }
    
    }

    //Print the number of edges and nodes in the dataset
    println!("The dataset contains {} edges", count);
    println!("The dataset contains {} nodes", hashtags.len());

    //Return the hashtags HashSet or any errors encountered during processing
    Ok(hashtags)
}
