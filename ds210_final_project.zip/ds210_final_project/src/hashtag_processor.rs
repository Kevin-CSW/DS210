//Import the required modules and libraries
use csv::ReaderBuilder;
use std::error::Error;
use std::fs::File;
use std::collections::HashMap;

//Define a type alias `Collection` as a HashMap containing String keys and Vec<Vec<String>> values
type Collection = HashMap<String, Vec<Vec<String>>>;

//Declare a public struct HashtagCounter with two fields: hashtags and collection
pub struct HashtagCounter {
    hashtags: Vec<String>,
    collection: Collection,
}

//Implement methods for the HashtagCounter struct
impl HashtagCounter {

    //Define a public constructor method for HashtagCounter that takes a Vec<String> (hashtags) as an argument
    pub fn new(hashtags: Vec<String>) -> Self {
        HashtagCounter {
            hashtags,
            collection: HashMap::new(),
        }
    }

    //Define a private method to parse and clean up the input string of hashtags
    fn parse_tags(&self, tags_str: &str) -> Vec<String> {
        let trimmed = tags_str.trim_matches(|c| c == '[' || c == ']').replace('\'', "");
        trimmed.split(", ").map(|s| s.to_string()).collect()
    }

    //Define a private method to process the record by filtering out the main hashtag
    //and inserting the filtered hashtags into the collection
    fn process_record(&mut self, tags_vec: &[String], hashtag: &str) {
        let filtered_tags_vec: Vec<String> = tags_vec.iter().filter(|tag| tag.as_str() != hashtag).map(|s| s.to_string()).collect();
        self.collection
            .entry(hashtag.to_string())
            .or_insert_with(Vec::new)
            .push(filtered_tags_vec);
    }

    // Define a public method to count hashtags and their co-occurrences in the dataset
    pub fn count_hashtags(&mut self, filename: &str, numb: usize) -> Result<(), Box<dyn Error>> {
        let file = File::open(filename)?;
        let mut rdr = ReaderBuilder::new()
        .has_headers(true)
        .flexible(true)
        .from_reader(file);
        
        // Iterate over the records in the CSV file
        for result in rdr.records() {
            let record = result?;

            //Check for missing or abnormal data (e.g., "NA" or empty fields)
            //let has_na = record.iter().any(|field| field == "NA" || field.trim().is_empty());
            //This line is commented out because, for this specific dataset, the hashtag column is quite clean
            //compared to other columns, and dropping rows with NAs would result in a significant loss of data.
            //However, this code snippet is retained as it may be useful for handling other datasets.

            let tags_str = record.get(numb).unwrap_or_default();

            let tags_vec = self.parse_tags(tags_str);
            
            // Find the matching hashtags
            let mut matching_hashtags = Vec::new();
            for i in 0..self.hashtags.len() {
                let current_hashtag = &self.hashtags[i];
                if tags_vec.contains(current_hashtag) {
                    matching_hashtags.push(current_hashtag.clone());
                }
            }

            // Process the records for the matching hashtags
            for hashtag in matching_hashtags {
                self.process_record(&tags_vec, &hashtag);
            }
        
        }
        Ok(())
    }

    // Define a public method to return the collection from the HashtagCounter instance
    pub fn get_collection(self) -> Collection {
        self.collection
    }
}

