use std::error::Error;
use std::time::SystemTime;
pub mod hashtag_loader;
pub mod hashtag_processor;
pub mod weighted_graph_creator;
pub mod shortest_path;
pub mod rank_distance;

//Define a public function 'domain' that returns a Result<(), Box<dyn Error>>
pub fn domain() -> Result<(), Box<dyn Error>> {
    //Record the current system time as 'before'
    let before = SystemTime::now();

    //Read hashtags from a CSV file and collect them into a Vec<String>
    let hashtags = hashtag_loader::read_hashtags_from_file("Bitcoin_tweets_dataset_2.csv", 10)?
        .into_iter()
        .collect::<Vec<String>>();

    println!("Program running...");

    //Create a new HashtagCounter instance with the collected hashtags
    let mut hashtag_counter = hashtag_processor::HashtagCounter::new(hashtags);

    //Count the co-occurrences of hashtags in the dataset
    hashtag_counter.count_hashtags("Bitcoin_tweets_dataset_2.csv", 10)?;

    //Retrieve the collection of hashtag co-occurrences from the HashtagCounter instance
    let hashtag_data = hashtag_counter.get_collection();
    
    //Create the weighted graph where the nodes represent hashtags and 
    //the edges represent connections between hashtags with their weights
    //equal to the number of connections/co-occurrence.
    let hashtag_graph = weighted_graph_creator::construct_weighted_graph(hashtag_data);

    //Compute the shortest path distances from the hashtag "Bitcoin" to all other hashtags in the graph
    let shortest_distances = shortest_path::dijkstra_distances(&hashtag_graph, "Bitcoin");

    //Sort the distances in ascending order and display the top 100 shortest distances
    rank_distance::sorting_from_smallest(shortest_distances, 100);

    //Record the current system time as 'after'
    let after = SystemTime::now();

    //Calculate the difference between 'before' and 'after' times
    let difference = after.duration_since(before);
    let difference = difference.expect("Did the clock go back?");

    //Print the time it took for the entire process to complete
    println!("Time it took: {:?}", difference);

    //Return Ok(()) to indicate that the function completed successfully
    Ok(())
}

