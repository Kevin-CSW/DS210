use librs;
use std::error::Error;

fn main() -> Result<(), Box<dyn Error>> {
    return librs::domain();
}
